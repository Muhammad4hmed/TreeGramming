#include "decisiontree.h"
#include "ui_decisiontree.h"
#include <QInputDialog>
#include <QGraphicsScene>
#include <QGraphicsTextItem>

QGraphicsScene *scene;

class Node {
public:
    QString name;
    int age ;
    Node *leftChild , *rightChild;
    Node( QString n , int a , Node *leftChild , Node *rightChild ) {
        name = n ;
        age = a;
        this->leftChild = leftChild ;
        this->rightChild = rightChild ;
    }
};

class Tree {
public :
    int x = 0 , y = -100 ;
    Node *root = NULL ;
    void generateHeadTree( ) {
        QGraphicsTextItem *text = scene->addText("Person ");
        text->setPos( x - 20 , y );
        y += 20;
        scene->addLine( x , y , x - 80 , y + 30 );
        scene->addLine( x , y , x + 80 , y + 30 );
        y += 35 ;
        text = scene->addText("Male ");
        text->setPos( x - 90 , y );
        text = scene->addText("Female ");
        text->setPos( x + 80 , y );
    }
    void addNode( QString s , int age ) {
        if( root == NULL ) {
            root = new Node( s , age , NULL , NULL );
            QGraphicsTextItem *text = scene->addText(s + " " + QString::number(age) );
            text->setPos( x , y );
            y += 10 ;
            x += 20 ;
            scene->addLine( x , y + 5 , x , y + 40 );
            y += 50 ;
            return ;
        }
        if( root->leftChild == NULL ) {
            root->leftChild = new Node( s , age , NULL , NULL );
            scene->addLine( x , y + 5 , x - 50 , y + 30);
            QGraphicsTextItem *text = scene->addText(s + " "+ QString::number(age) );
            text->setPos( x , y );
        }
        else {
            root->rightChild = new Node( s , age , NULL , NULL );
            scene->addLine( x , y + 5 , x + 50 , y + 30);
            QGraphicsTextItem *text = scene->addText(s + " "+ QString::number(age) );
            text->setPos( x , y );
        }
    }
};

Tree t;

void AddNode( ) {
    QString name;
    int age ;
    bool ok , goodToGo;
    QString text = QInputDialog::getText(0 , "Enter Name ", "Name: ",QLineEdit::Normal, "", &ok );
    if( ok && !text.isEmpty() ) {
        name = text ;
    }
    text = QInputDialog::getText(0 , "Enter Age ", "Age: ",QLineEdit::Normal, "", &ok );
    if( ok && !text.isEmpty() ) {
        age = text.toInt();
        goodToGo = true;
    }
    if( goodToGo ) t.addNode( name , age );
}
void RemoveNode() {

}
void ClearTree() {
    scene->clear();
}
DecisionTree::DecisionTree(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DecisionTree)
{
    ui->setupUi(this);
    setFixedSize( width() , height() );
    scene = new QGraphicsScene;
    ui->graphicsView->setScene(scene);
    t.generateHeadTree();
}
DecisionTree::~DecisionTree()
{
    delete ui;
}

void DecisionTree::on_pushButton_3_clicked()
{
    AddNode();
}

void DecisionTree::on_pushButton_2_clicked()
{
    RemoveNode();
}

void DecisionTree::on_pushButton_clicked()
{
    ClearTree();
}
